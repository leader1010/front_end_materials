import { createApp } from 'vue'
// import App from './App.vue'
// import App from './components/01.Count/App.vue'
// import App from './components/02.computed/App.vue'
// import App from './components/03.customEvent/App.vue'
import App from './components/04.v-model/App.vue'

createApp(App).mount('#app')
